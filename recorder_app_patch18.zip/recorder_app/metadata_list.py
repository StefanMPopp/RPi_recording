"""
metadata_list.py
================
Loads a CSV of session metadata so the experimenter can step through
pre-planned recordings instead of typing fields between trials.

Column convention
-----------------
Three column names are reserved and map to fixed fields:

    experimenter, experiment, trial

EVERY OTHER COLUMN IS TREATED AS A TREATMENT. The column name becomes the
treatment name and the cell becomes its value. So a CSV like:

    experiment,trial,density,light
    foraging,1,high,dim
    foraging,2,low,bright

produces two sessions, each with two treatments (density and light).

Column names are matched case-insensitively and stripped of surrounding
whitespace, since spreadsheet exports frequently carry both.
"""

from __future__ import annotations

import csv
from dataclasses import dataclass, field
from pathlib import Path


# Columns that are NOT treatments
RESERVED_COLUMNS = {"experimenter", "experiment", "trial"}


# =============================================================================
# One row of the list
# =============================================================================

@dataclass
class MetadataRow:
    """One planned recording session."""
    experimenter: str = "NA"
    experiment:   str = "NA"
    trial:        str = "NA"
    treatments:   dict[str, str] = field(default_factory=dict)
    row_number:   int = 0

    def summary(self, max_length: int = 60) -> str:
        """Short one-line description for the dropdown."""
        treatment_part = ", ".join(f"{name}={value}"
                                   for name, value in self.treatments.items())
        parts = [self.experiment, treatment_part, f"trial {self.trial}"]
        text  = "  ·  ".join(part for part in parts if part and part != "NA")
        if len(text) > max_length:
            text = text[:max_length - 1] + "…"
        return text or f"row {self.row_number}"


# =============================================================================
# Loading
# =============================================================================

def load_metadata_list(csv_file: Path) -> tuple[list[MetadataRow], list[str]]:
    """
    Read a metadata CSV.

    Returns (rows, warnings). Warnings describe recoverable problems
    (blank rows skipped, no treatment columns found) so the UI can surface
    them without failing the whole load.
    """
    warnings: list[str] = []
    rows:     list[MetadataRow] = []

    with csv_file.open("r", newline="", encoding="utf-8-sig") as file_handle:
        reader = csv.DictReader(file_handle)

        if not reader.fieldnames:
            raise ValueError("The file has no header row.")

        # Map normalised -> original column names so lookups are forgiving
        column_map = {
            (name or "").strip().lower(): name
            for name in reader.fieldnames
        }
        treatment_columns = [
            original for normalised, original in column_map.items()
            if normalised not in RESERVED_COLUMNS and normalised
        ]

        if not treatment_columns:
            warnings.append(
                "No treatment columns found — every column matched a reserved "
                "name (experimenter, experiment, trial)."
            )

        for row_index, raw_row in enumerate(reader, start=1):
            # Skip entirely blank lines
            if not any((value or "").strip() for value in raw_row.values()):
                continue

            def cell(normalised_name: str) -> str:
                original = column_map.get(normalised_name)
                if original is None:
                    return "NA"
                return (raw_row.get(original) or "").strip() or "NA"

            treatments = {}
            for column in treatment_columns:
                value = (raw_row.get(column) or "").strip()
                if value:
                    treatments[column.strip()] = value

            rows.append(MetadataRow(
                experimenter = cell("experimenter"),
                experiment   = cell("experiment"),
                trial        = cell("trial"),
                treatments   = treatments,
                row_number   = row_index,
            ))

    if not rows:
        raise ValueError("The file contains a header but no data rows.")

    return rows, warnings


# =============================================================================
# Filename generation
# =============================================================================

def build_auto_file_name(
    experiment: str,
    treatments: dict[str, str],
    trial: str,
    include_treatment_names: bool = False,
) -> str:
    """
    Build the automatic file name from metadata:

        {experiment}_{treatments}_{trial}

    Treatments are joined with '-'. With include_treatment_names, each is
    written as name-value; otherwise only values are used:

        values only:  foraging_high-dim_3
        with names:   foraging_density-high-light-dim_3

    Empty and "NA" parts are omitted rather than appearing literally.
    Characters unsafe in filenames are replaced with underscores.
    """
    def clean(text: str) -> str:
        text = (text or "").strip()
        if not text or text.upper() == "NA":
            return ""
        # Replace path separators and other awkward characters
        for character in '/\\:*?"<>|':
            text = text.replace(character, "_")
        return text.replace(" ", "-")

    if include_treatment_names:
        treatment_parts = [
            f"{clean(name)}-{clean(value)}"
            for name, value in treatments.items()
            if clean(name) and clean(value)
        ]
    else:
        treatment_parts = [
            clean(value) for value in treatments.values() if clean(value)
        ]

    parts = [
        clean(experiment),
        "-".join(treatment_parts),
        clean(trial),
    ]
    file_name = "_".join(part for part in parts if part)
    return file_name or "recording"
