"""
main_window.py
==============
Main application window for the RPi Recorder.

Layout (setup mode):
┌─────────────────────┬──────────────────────────────────────┐
│                     │  Recording settings                  │
│   Preview widget    │  ─────────────────────────────────── │
│   (with zoom)       │  Metadata                            │
│                     │  ─────────────────────────────────── │
│                     │  Save / Load profile                 │
├─────────────────────┴──────────────────────────────────────┤
│  [ ▶ Start recording ]        status bar                   │
└────────────────────────────────────────────────────────────┘

During recording the right panel switches to a live status view.
"""

from __future__ import annotations

from pathlib import Path

from PyQt6.QtCore    import Qt, QTimer, pyqtSignal, QThread, QPoint
from PyQt6.QtGui     import QImage, QPixmap, QFont, QColor, QPalette, QAction, QCursor
from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QLabel, QPushButton,
    QHBoxLayout, QVBoxLayout, QGridLayout, QSplitter,
    QComboBox, QLineEdit, QSpinBox, QDoubleSpinBox, QCheckBox,
    QFileDialog, QToolTip, QStatusBar, QMenuBar,
    QGroupBox, QSizePolicy, QFrame, QScrollArea, QTextEdit, QStyle,
    QRadioButton, QButtonGroup,
)

import numpy as np

from constants  import (
    APP_NAME, APP_VERSION,
    PREVIEW_WIDTH,
    OUTPUT_FORMATS, METADATA_DEFAULTS,
    COLOUR_MODES, DEFAULT_COLOUR_MODE,
)
from config     import load_app_config, save_app_config, load_profile, save_profile, default_profile
from benchmark  import (
    get_free_space_gb, compute_headroom, compute_max_record_time_s,
    estimate_file_size_per_minute_gb,
)
from camera     import make_camera, SensorMode
from record     import RecordingSession, RecordingSettings
from metadata   import build_metadata, write_metadata
from metadata_list import load_metadata_list, build_auto_file_name, MetadataRow


# =============================================================================
# Colour palette  (dark, instrument-style)
# =============================================================================
# Inspired by oscilloscope / scientific instrument UIs:
# near-black background, cool grey panels, amber accent for live data.

COLOUR = {
    "bg":           "#1A1D21",   # main window background
    "panel":        "#22262C",   # panel / groupbox background
    "border":       "#353A42",   # subtle borders
    "text":         "#D8DCE3",   # primary text
    "text_dim":     "#7A8190",   # labels, units
    "accent":       "#E8A020",   # amber — live recording indicator, headings
    "green":        "#4CAF50",
    "amber":        "#FFA726",
    "red":          "#EF5350",
    "button_start": "#2E7D32",   # start button
    "button_stop":  "#B71C1C",   # stop button
}

STYLE_SHEET = f"""
    QMainWindow, QWidget {{
        background-color: {COLOUR["bg"]};
        color: {COLOUR["text"]};
        font-family: "DejaVu Sans", "Segoe UI", sans-serif;
        font-size: 13px;
    }}
    QGroupBox {{
        background-color: {COLOUR["panel"]};
        border: 1px solid {COLOUR["border"]};
        border-radius: 6px;
        margin-top: 10px;
        padding: 8px;
        font-size: 11px;
        color: {COLOUR["text_dim"]};
        text-transform: uppercase;
        letter-spacing: 0.08em;
    }}
    QGroupBox::title {{
        subcontrol-origin: margin;
        subcontrol-position: top left;
        padding: 0 6px;
    }}
    QLineEdit, QComboBox, QSpinBox, QDoubleSpinBox {{
        background-color: {COLOUR["bg"]};
        border: 1px solid {COLOUR["border"]};
        border-radius: 4px;
        padding: 4px 8px;
        color: {COLOUR["text"]};
        selection-background-color: {COLOUR["accent"]};
    }}
    QLineEdit:disabled, QComboBox:disabled, QSpinBox:disabled, QDoubleSpinBox:disabled {{
        background-color: #1B1E23;
        color: #4A4F58;
        border: 1px dashed {COLOUR["border"]};
    }}
    QComboBox::drop-down {{ border: none; }}
    QPushButton {{
        background-color: {COLOUR["panel"]};
        border: 1px solid {COLOUR["border"]};
        border-radius: 4px;
        padding: 6px 14px;
        color: {COLOUR["text"]};
    }}
    QPushButton:hover  {{ border-color: {COLOUR["accent"]}; }}
    QPushButton:pressed {{ background-color: {COLOUR["border"]}; }}
    QLabel {{ background: transparent; }}
    QRadioButton {{
        color: {COLOUR["text"]};
        font-size: 12px;
        spacing: 5px;
    }}
    QRadioButton::indicator {{
        width: 12px;
        height: 12px;
        border-radius: 7px;
        border: 1px solid {COLOUR["border"]};
        background-color: {COLOUR["bg"]};
    }}
    QRadioButton::indicator:checked {{
        background-color: {COLOUR["accent"]};
        border: 3px solid {COLOUR["bg"]};
        outline: 1px solid {COLOUR["accent"]};
    }}
    QSplitter::handle {{ background-color: {COLOUR["border"]}; width: 1px; }}
    QScrollArea {{ border: none; }}
    QStatusBar {{ background-color: {COLOUR["panel"]}; color: {COLOUR["text_dim"]}; }}
    QMenuBar {{
        background-color: {COLOUR["panel"]};
        border-bottom: 1px solid {COLOUR["border"]};
    }}
    QMenuBar::item:selected {{ background-color: {COLOUR["border"]}; }}
    QMenu {{
        background-color: {COLOUR["panel"]};
        border: 1px solid {COLOUR["border"]};
    }}
    QMenu::item:selected {{ background-color: {COLOUR["border"]}; }}
"""



# =============================================================================
# Monospace popup — used as a custom tooltip for tables that need fixed-width
# =============================================================================

class MonospacePopup(QFrame):
    """
    A frameless floating window that displays monospaced text.
    Used instead of QToolTip so we can force a monospace font,
    which is required for the format comparison table to align correctly.
    Closes when the mouse leaves the triggering widget.
    """

    def __init__(self, parent=None):
        super().__init__(parent, Qt.WindowType.ToolTip)
        self.setFrameShape(QFrame.Shape.StyledPanel)
        self.setStyleSheet(f"""
            QFrame {{
                background-color: #2A2F38;
                border: 1px solid {COLOUR['accent']};
                border-radius: 4px;
            }}
            QLabel {{
                color: {COLOUR['text']};
                font-family: "DejaVu Sans Mono", "Courier New", monospace;
                font-size: 12px;
                padding: 10px 14px;
            }}
        """)
        self._label = QLabel()
        self._label.setTextFormat(Qt.TextFormat.PlainText)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.addWidget(self._label)

    def show_text(self, text: str, anchor_global: QPoint) -> None:
        """
        Display text with the popup's top-right corner at anchor_global.
        anchor_global should be the bottom-right corner of the triggering
        widget, so the popup opens leftward and below — never under the
        cursor, which would cause hover flicker.
        """
        self._label.setText(text)
        self.adjustSize()

        screen        = QApplication.primaryScreen().availableGeometry()
        popup_width   = self.width()
        popup_height  = self.height()

        # Open leftward from the anchor
        x = anchor_global.x() - popup_width
        x = max(screen.left() + 4, min(x, screen.right() - popup_width - 4))

        # Open downward; flip above the anchor if it would run off the bottom
        y = anchor_global.y() + 6
        if y + popup_height > screen.bottom():
            y = max(screen.top() + 4, anchor_global.y() - popup_height - 6)

        self.move(x, y)
        self.show()
        self.raise_()


class InfoButton(QLabel):
    """
    A small blue circular 'i' button that shows a MonospacePopup on hover.

    The circle is drawn with CSS rather than using the ⓘ unicode glyph,
    because that glyph is missing from many Linux system fonts and renders
    as an empty box.
    """

    _DIAMETER = 17

    def __init__(self, popup_text: str = "", parent=None):
        super().__init__("i", parent)
        self._popup_text = popup_text
        self._popup      = MonospacePopup()

        self.setFixedSize(self._DIAMETER, self._DIAMETER)
        self.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.setStyleSheet(f"""
            QLabel {{
                background-color: #2C5F8D;
                color: #CFE4F7;
                border: 1px solid #4A90D9;
                border-radius: {self._DIAMETER // 2}px;
                font-family: "DejaVu Serif", Georgia, serif;
                font-size: 11px;
                font-weight: bold;
                font-style: italic;
            }}
        """)
        self.setCursor(Qt.CursorShape.PointingHandCursor)

    def set_text(self, text: str) -> None:
        self._popup_text = text

    def enterEvent(self, event) -> None:
        if self._popup_text:
            # Anchor = bottom-right corner of the button, in screen coordinates
            anchor = self.mapToGlobal(QPoint(self.width(), self.height()))
            self._popup.show_text(self._popup_text, anchor)
        super().enterEvent(event)

    def leaveEvent(self, event) -> None:
        self._popup.hide()
        super().leaveEvent(event)


# =============================================================================
# Treatment fields — user-definable name/value pairs, any number of them
# =============================================================================

class TreatmentRow(QWidget):
    """
    A single treatment: editable name, editable value, and a remove button.
    Both fields are free text so any category the experiment needs can be
    defined at recording time.
    """

    removed = pyqtSignal(object)     # emits self
    changed = pyqtSignal()

    def __init__(self, name: str = "", value: str = "", parent=None):
        super().__init__(parent)
        layout = QHBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(4)

        self.name_edit = QLineEdit(name)
        self.name_edit.setPlaceholderText("name")
        self.name_edit.setFixedWidth(90)
        self.name_edit.textChanged.connect(self.changed)

        self.value_edit = QLineEdit(value)
        self.value_edit.setPlaceholderText("value")
        self.value_edit.setMinimumWidth(70)
        self.value_edit.textChanged.connect(self.changed)

        remove_button = QPushButton("✕")
        remove_button.setFixedSize(22, 22)
        remove_button.setToolTip("Remove this treatment")
        remove_button.setStyleSheet(
            f"color: {COLOUR['text_dim']}; font-size: 11px; padding: 0;"
        )
        remove_button.clicked.connect(lambda: self.removed.emit(self))

        layout.addWidget(self.name_edit)
        layout.addWidget(self.value_edit)
        layout.addWidget(remove_button)

    def get_pair(self) -> tuple[str, str]:
        return self.name_edit.text().strip(), self.value_edit.text().strip()


class TreatmentList(QWidget):
    """
    A growable list of TreatmentRow widgets with an 'Add treatment' button.
    Replaces the former single fixed Treatment field.
    """

    changed = pyqtSignal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self._rows: list[TreatmentRow] = []

        outer_layout = QVBoxLayout(self)
        outer_layout.setContentsMargins(0, 0, 0, 0)
        outer_layout.setSpacing(4)

        self._rows_container = QVBoxLayout()
        self._rows_container.setContentsMargins(0, 0, 0, 0)
        self._rows_container.setSpacing(4)
        outer_layout.addLayout(self._rows_container)

        add_button = QPushButton("+  Add treatment")
        add_button.setStyleSheet("font-size: 11px; padding: 3px 10px;")
        add_button.clicked.connect(lambda: self.add_row())
        add_row_layout = QHBoxLayout()
        add_row_layout.setContentsMargins(0, 0, 0, 0)
        add_row_layout.addWidget(add_button)
        add_row_layout.addStretch()
        outer_layout.addLayout(add_row_layout)

    # ── Row management ─────────────────────────────────────────────────────────

    def add_row(self, name: str = "", value: str = "") -> TreatmentRow:
        row = TreatmentRow(name, value)
        row.removed.connect(self._remove_row)
        row.changed.connect(self.changed)
        self._rows.append(row)
        self._rows_container.addWidget(row)
        self.changed.emit()
        return row

    def _remove_row(self, row: TreatmentRow) -> None:
        if row in self._rows:
            self._rows.remove(row)
            self._rows_container.removeWidget(row)
            row.deleteLater()
            self.changed.emit()

    def clear(self) -> None:
        for row in list(self._rows):
            self._rows.remove(row)
            self._rows_container.removeWidget(row)
            row.deleteLater()

    # ── Value access ───────────────────────────────────────────────────────────

    def get_treatments(self) -> dict[str, str]:
        """Return {name: value}; rows with either field blank are skipped."""
        treatments = {}
        for row in self._rows:
            name, value = row.get_pair()
            if name and value:
                treatments[name] = value
        return treatments

    def set_treatments(self, treatments: dict[str, str]) -> None:
        """Replace all rows with the given name/value pairs."""
        self.clear()
        for name, value in (treatments or {}).items():
            self.add_row(str(name), str(value))
        self.changed.emit()


# =============================================================================
# Preview widget — displays camera frames, handles ctrl+scroll zoom
# =============================================================================

class PreviewWidget(QLabel):
    """
    Displays numpy frames from the camera preview stream.

    Mouse controls:
      Ctrl + scroll   zoom in/out, centred on the cursor
      scroll          pan up/down   (when zoomed in)
      Shift + scroll  pan left/right (when zoomed in)

    The view is described by a zoom factor and a centre point in normalised
    frame coordinates. The centre is clamped so the visible crop can never
    extend past the frame edge — clamping the centre rather than the crop
    is what prevents the view from jumping when you pan into a corner.
    """

    zoom_changed = pyqtSignal(float)

    _MIN_ZOOM  = 1.0
    _MAX_ZOOM  = 12.0
    _ZOOM_STEP = 1.15
    _PAN_STEP  = 0.06     # fraction of the visible width/height per scroll notch

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMinimumSize(480, 360)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        self.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.setStyleSheet(
            f"background-color: #0A0C0E; border: 1px solid {COLOUR['border']}; "
            f"border-radius: 4px;"
        )
        self.setText("No camera signal")

        self._zoom_factor   = 1.0
        self._centre_x      = 0.5    # normalised centre of the visible region
        self._centre_y      = 0.5
        self._current_frame: np.ndarray | None = None

    # ── Frame ingestion ────────────────────────────────────────────────────────

    def update_frame(self, frame_array: np.ndarray) -> None:
        self._current_frame = frame_array
        self._render()

    def _render(self) -> None:
        if self._current_frame is None:
            return

        frame = self._current_frame

        # Normalise to RGB — the camera may deliver greyscale (2D) or RGBA
        if frame.ndim == 2:
            frame = np.stack([frame, frame, frame], axis=2)
        elif frame.shape[2] == 4:
            frame = frame[:, :, :3]

        frame_height, frame_width = frame.shape[:2]

        if self._zoom_factor > 1.0:
            crop_width  = max(1, int(frame_width  / self._zoom_factor))
            crop_height = max(1, int(frame_height / self._zoom_factor))
            left = int(self._centre_x * frame_width  - crop_width  / 2)
            top  = int(self._centre_y * frame_height - crop_height / 2)
            # Centre is already clamped, so these are belt-and-braces only
            left = max(0, min(left, frame_width  - crop_width))
            top  = max(0, min(top,  frame_height - crop_height))
            frame = frame[top:top + crop_height, left:left + crop_width]

        rgb_frame      = np.ascontiguousarray(frame)
        height, width, channels = rgb_frame.shape
        bytes_per_line = channels * width
        qt_image = QImage(
            rgb_frame.data, width, height, bytes_per_line, QImage.Format.Format_RGB888
        )
        # Scale to the widget's CURRENT size, so the whole frame is always
        # visible regardless of window size or frame aspect ratio
        pixmap = QPixmap.fromImage(qt_image).scaled(
            self.size(),
            Qt.AspectRatioMode.KeepAspectRatio,
            Qt.TransformationMode.FastTransformation,
        )
        self.setPixmap(pixmap)

    def resizeEvent(self, event) -> None:
        # Re-render at the new widget size so the frame refits immediately
        self._render()
        super().resizeEvent(event)

    # ── View manipulation ──────────────────────────────────────────────────────

    def _clamp_centre(self) -> None:
        """
        Keep the visible region inside the frame. At zoom Z the visible region
        is 1/Z of the frame, so the centre must stay at least half of that
        away from each edge.
        """
        half_extent = 0.5 / self._zoom_factor
        lower, upper = half_extent, 1.0 - half_extent
        if lower >= upper:          # fully zoomed out
            self._centre_x = self._centre_y = 0.5
        else:
            self._centre_x = max(lower, min(self._centre_x, upper))
            self._centre_y = max(lower, min(self._centre_y, upper))

    def reset_view(self) -> None:
        self._zoom_factor = 1.0
        self._centre_x = self._centre_y = 0.5
        self.zoom_changed.emit(self._zoom_factor)
        self._render()

    def wheelEvent(self, event) -> None:
        notches   = event.angleDelta().y() / 120.0
        modifiers = event.modifiers()

        if modifiers & Qt.KeyboardModifier.ControlModifier:
            self._zoom_at_cursor(event, notches)
        elif modifiers & Qt.KeyboardModifier.ShiftModifier:
            self._pan(dx_notches=notches, dy_notches=0.0)
        else:
            self._pan(dx_notches=0.0, dy_notches=notches)

        event.accept()

    def _zoom_at_cursor(self, event, notches: float) -> None:
        """
        Zoom about the cursor: the frame point under the cursor stays under
        the cursor. Without this the view appears to slide as you zoom.
        """
        old_zoom = self._zoom_factor
        new_zoom = old_zoom * (self._ZOOM_STEP ** notches)
        new_zoom = max(self._MIN_ZOOM, min(new_zoom, self._MAX_ZOOM))
        if new_zoom == old_zoom:
            return

        # Cursor position as a fraction of the widget, offset from its centre
        cursor    = event.position()
        offset_x  = (cursor.x() / max(1, self.width()))  - 0.5
        offset_y  = (cursor.y() / max(1, self.height())) - 0.5

        # Frame coordinate currently under the cursor
        frame_x = self._centre_x + offset_x / old_zoom
        frame_y = self._centre_y + offset_y / old_zoom

        # Move the centre so that same coordinate stays under the cursor
        self._centre_x = frame_x - offset_x / new_zoom
        self._centre_y = frame_y - offset_y / new_zoom
        self._zoom_factor = new_zoom

        self._clamp_centre()
        self.zoom_changed.emit(self._zoom_factor)
        self._render()

    def _pan(self, dx_notches: float, dy_notches: float) -> None:
        """Pan the view. Step size scales with zoom so it feels consistent."""
        if self._zoom_factor <= 1.0:
            return   # nothing to pan when the whole frame is visible

        step = self._PAN_STEP / self._zoom_factor
        # Scrolling up (positive notches) moves the view up, i.e. centre down
        self._centre_x -= dx_notches * step
        self._centre_y -= dy_notches * step

        self._clamp_centre()
        self._render()

    def mouseDoubleClickEvent(self, event) -> None:
        """Double-click resets the view to fully zoomed out."""
        self.reset_view()
        super().mouseDoubleClickEvent(event)


# =============================================================================
# Format tooltip builder — single table covering all formats
# =============================================================================

def _build_all_formats_tooltip(
    sensor_mode: SensorMode | None,
    selected_fps: float,
    channels: int,
    write_speed_mbs: float | None,
    free_space_gb: float | None,
) -> str:
    """
    Build a monospace table covering all output formats at the
    currently selected resolution and framerate.
    Columns: Format | Description | Write rate | Size/min | Headroom | Max time
    """
    # ── Column widths ──────────────────────────────────────────────────────────
    W_FMT  = 22   # format name
    W_DESC = 38   # short description
    W_RATE = 12   # write rate
    W_SIZE = 11   # size per min
    W_HEAD = 10   # headroom
    W_TIME = 10   # max time

    header = (
        f"{'Format':<{W_FMT}}"
        f"{'Description':<{W_DESC}}"
        f"{'Write rate':>{W_RATE}}"
        f"{'Size/min':>{W_SIZE}}"
        f"{'Headroom':>{W_HEAD}}"
        f"{'Max time':>{W_TIME}}"
    )
    separator = "─" * (W_FMT + W_DESC + W_RATE + W_SIZE + W_HEAD + W_TIME)

    if sensor_mode is not None:
        colour_name = "greyscale" if channels == 1 else "colour"
        heading = (
            f"Output format comparison  —  {sensor_mode.width}×{sensor_mode.height} "
            f"@ {selected_fps:.1f} fps, {colour_name}"
        )
    else:
        heading = "Output format comparison"

    lines = [
        heading,
        separator,
        header,
        separator,
    ]

    # Short descriptions — one per format, matched by display_label
    DESCRIPTIONS = {
        "MJPEG video (.avi)": "Each frame compressed independently",
        "TIFF image stack":   "Uncompressed",
        "PNG image stack":    "Lossless compressed images",
        "H.264 video (.mp4)": "Inter-frame compr.: fast moves blur?",
    }

    icon = {"green": "✔", "amber": "⚠", "red": "✖"}

    if sensor_mode is None or write_speed_mbs is None:
        for display_label, _ext, _ in OUTPUT_FORMATS:
            desc = DESCRIPTIONS.get(display_label, "")
            lines.append(
                f"{display_label:<{W_FMT}}"
                f"{desc:<{W_DESC}}"
                f"{'—':>{W_RATE}}"
                f"{'—':>{W_SIZE}}"
                f"{'—':>{W_HEAD}}"
                f"{'—':>{W_TIME}}"
            )
    else:
        for display_label, _ext, _ in OUTPUT_FORMATS:
            desc         = DESCRIPTIONS.get(display_label, "")
            headroom     = compute_headroom(
                display_label, sensor_mode.width, sensor_mode.height,
                selected_fps, write_speed_mbs, channels,
            )
            size_per_min = estimate_file_size_per_minute_gb(
                display_label, sensor_mode.width, sensor_mode.height,
                selected_fps, channels,
            )
            max_time_str = "—"
            if free_space_gb is not None:
                max_time_s = compute_max_record_time_s(
                    display_label, sensor_mode.width, sensor_mode.height,
                    selected_fps, free_space_gb, channels,
                )
                if max_time_s is not None:
                    max_time_str = f"{max_time_s / 60:.0f} min"

            headroom_str = f"{headroom['headroom_pct']:.0f}% {icon[headroom['colour']]}"
            rate_str     = f"{headroom['write_rate_mbs']:.1f} MB/s"
            size_str     = f"{size_per_min:.2f} GB"

            lines.append(
                f"{display_label:<{W_FMT}}"
                f"{desc:<{W_DESC}}"
                f"{rate_str:>{W_RATE}}"
                f"{size_str:>{W_SIZE}}"
                f"{headroom_str:>{W_HEAD}}"
                f"{max_time_str:>{W_TIME}}"
            )

    lines.append(separator)
    if free_space_gb is not None and write_speed_mbs is not None:
        lines.append(
            f"Free: {free_space_gb:.1f} GB    "
            f"Write speed: {write_speed_mbs:.1f} MB/s    "
            f"Recalibrate: Settings → Recalibrate write speed"
        )
    else:
        lines.append("Calibrate write speed: Settings → Recalibrate write speed")

    return "\n".join(lines)


# =============================================================================
# Main window
# =============================================================================

class MainWindow(QMainWindow):

    frame_ready = pyqtSignal(np.ndarray)   # camera thread → UI thread

    def __init__(self):
        super().__init__()

        self._app_config     = load_app_config()
        self._profile        = default_profile()
        self._camera         = make_camera()
        self._is_recording   = False
        self._free_space_gb: float | None = None

        # Metadata list (CSV) state
        self._metadata_rows: list = []
        self._metadata_list_file = None

        # Spatial calibration anchor: the scene width the FULL sensor would
        # see, in cm. Stored independently of sensor mode so the calibration
        # survives mode changes correctly. None = not calibrated.
        self._full_fov_width_cm: float | None = None

        # Recording state
        self._session: RecordingSession | None = None
        self._recording_settings: RecordingSettings | None = None
        self._status_timer = QTimer(self)
        self._status_timer.timeout.connect(self._update_recording_status)

        self.setWindowTitle(f"{APP_NAME}  {APP_VERSION}")
        # Wide enough for a 4:3 preview (the tallest aspect the sensor offers)
        # beside the fixed 420 px control panel, without manual resizing
        self.setMinimumSize(1180, 700)
        self.resize(1500, 900)
        self.setStyleSheet(STYLE_SHEET)

        self._build_menu()
        self._build_ui()
        self._populate_sensor_modes()          # also sets initial fps on the camera
        self._camera.set_colour_mode(self._current_channels())
        self._on_format_changed(self._format_combo.currentIndex())
        self._on_scale_mode_changed()          # sets which scale field is editable
        self._on_auto_name_toggled(0)          # applies auto file naming
        self._refresh_free_space()
        self._start_preview()

        # Connect camera frames to preview widget via Qt signal (thread-safe)
        self.frame_ready.connect(self._preview_widget.update_frame)

    # =========================================================================
    # Menu bar
    # =========================================================================

    def _build_menu(self) -> None:
        menu_bar = self.menuBar()

        # File menu
        file_menu = menu_bar.addMenu("File")
        load_action = QAction("Load profile…", self)
        load_action.triggered.connect(self._on_load_profile)
        save_action = QAction("Save profile…", self)
        save_action.triggered.connect(self._on_save_profile)
        file_menu.addAction(load_action)
        file_menu.addAction(save_action)

        # Settings menu
        settings_menu = menu_bar.addMenu("Settings")
        benchmark_action = QAction("Recalibrate write speed…", self)
        benchmark_action.triggered.connect(self._on_recalibrate_write_speed)
        settings_menu.addAction(benchmark_action)

        settings_menu.addSeparator()

        # File naming: whether treatment names appear alongside their values
        self._treatment_names_action = QAction("Include treatment names in file name", self)
        self._treatment_names_action.setCheckable(True)
        self._treatment_names_action.setChecked(
            self._app_config["app"].get("include_treatment_names", False)
        )
        self._treatment_names_action.toggled.connect(self._on_treatment_names_toggled)
        settings_menu.addAction(self._treatment_names_action)

    # =========================================================================
    # UI construction
    # =========================================================================

    def _build_ui(self) -> None:
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        outer_layout   = QVBoxLayout(central_widget)
        outer_layout.setContentsMargins(8, 8, 8, 8)
        outer_layout.setSpacing(6)

        # ── Main splitter: preview (left) | controls (right) ──────────────────
        splitter = QSplitter(Qt.Orientation.Horizontal)
        splitter.setHandleWidth(2)

        # Left: preview
        self._preview_widget = PreviewWidget()
        preview_panel        = self._build_preview_panel()
        splitter.addWidget(preview_panel)

        # Right: scrollable controls — fixed width so it never crowds the preview
        self._setup_panel    = self._build_setup_panel()
        self._status_panel   = self._build_status_panel()
        self._status_panel.setVisible(False)

        right_widget = QWidget()
        right_widget.setFixedWidth(420)
        right_layout = QVBoxLayout(right_widget)
        right_layout.setContentsMargins(0, 0, 0, 0)
        right_layout.setSpacing(0)
        right_layout.addWidget(self._setup_panel)
        right_layout.addWidget(self._status_panel)
        splitter.addWidget(right_widget)

        splitter.setStretchFactor(0, 1)   # preview takes all remaining space
        splitter.setStretchFactor(1, 0)
        outer_layout.addWidget(splitter, stretch=1)

        # ── Bottom bar: record button + status ────────────────────────────────
        outer_layout.addWidget(self._build_bottom_bar())

        # Status bar
        self._status_bar_label = QLabel("Ready")
        self.statusBar().addWidget(self._status_bar_label)

    # ── Preview panel ──────────────────────────────────────────────────────────

    def _build_preview_panel(self) -> QWidget:
        panel  = QWidget()
        layout = QVBoxLayout(panel)
        layout.setContentsMargins(0, 0, 4, 0)
        layout.setSpacing(4)

        # Header row: title on the left, zoom readout on the right
        header_row = QHBoxLayout()
        header = QLabel("Live preview")
        header.setStyleSheet(
            f"color: {COLOUR['text_dim']}; font-size: 11px; text-transform: uppercase;"
        )
        self._zoom_label = QLabel("zoom 1.0×")
        self._zoom_label.setStyleSheet(
            f"color: {COLOUR['text_dim']}; font-size: 11px; "
            f"font-family: 'DejaVu Sans Mono', monospace;"
        )
        self._zoom_reset_button = QPushButton("Reset view")
        self._zoom_reset_button.setFixedHeight(20)
        self._zoom_reset_button.setStyleSheet("font-size: 11px; padding: 1px 8px;")
        self._zoom_reset_button.setVisible(False)
        header_row.addWidget(header)
        header_row.addStretch()
        header_row.addWidget(self._zoom_label)
        header_row.addWidget(self._zoom_reset_button)
        layout.addLayout(header_row)

        layout.addWidget(self._preview_widget, stretch=1)

        # Control hints
        zoom_hint = QLabel(
            "Ctrl + scroll: zoom     ·     scroll: pan up/down     ·     "
            "Shift + scroll: pan left/right     ·     double-click: reset"
        )
        zoom_hint.setStyleSheet(f"color: {COLOUR['text_dim']}; font-size: 11px;")
        zoom_hint.setAlignment(Qt.AlignmentFlag.AlignRight)
        layout.addWidget(zoom_hint)

        # Wire zoom readout
        self._preview_widget.zoom_changed.connect(self._on_zoom_changed)
        self._zoom_reset_button.clicked.connect(self._preview_widget.reset_view)

        return panel

    def _on_zoom_changed(self, zoom_factor: float) -> None:
        self._zoom_label.setText(f"zoom {zoom_factor:.1f}×")
        is_zoomed = zoom_factor > 1.001
        self._zoom_reset_button.setVisible(is_zoomed)
        self._zoom_label.setStyleSheet(
            f"color: {COLOUR['accent'] if is_zoomed else COLOUR['text_dim']}; "
            f"font-size: 11px; font-family: 'DejaVu Sans Mono', monospace;"
        )

    # ── Setup panel (right side, pre-recording) ────────────────────────────────

    def _build_setup_panel(self) -> QScrollArea:
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        scroll.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)

        container  = QWidget()
        layout     = QVBoxLayout(container)
        layout.setSpacing(10)
        layout.setContentsMargins(6, 4, 12, 4)   # extra right margin avoids scrollbar overlap

        layout.addWidget(self._build_camera_group())
        layout.addWidget(self._build_output_group())
        layout.addWidget(self._build_metadata_group())
        layout.addWidget(self._build_profile_group())
        layout.addStretch()

        scroll.setWidget(container)
        return scroll

    # ── Camera settings group ──────────────────────────────────────────────────

    def _build_camera_group(self) -> QGroupBox:
        group  = QGroupBox("Camera")
        layout = QGridLayout(group)
        layout.setColumnStretch(1, 1)
        layout.setVerticalSpacing(6)

        row = 0

        # Sensor mode dropdown — sets resolution, bit depth, and the fps ceiling
        layout.addWidget(self._dim_label("Sensor mode"), row, 0)
        self._sensor_mode_combo = QComboBox()
        self._sensor_mode_combo.setFixedWidth(200)
        self._sensor_mode_combo.currentIndexChanged.connect(self._on_sensor_mode_changed)
        layout.addWidget(self._sensor_mode_combo, row, 1)
        row += 1

        # Framerate — any value up to the selected mode's maximum
        layout.addWidget(self._dim_label("Framerate"), row, 0)
        fps_row = QHBoxLayout()
        fps_row.setSpacing(6)
        self._fps_spin = QDoubleSpinBox()
        self._fps_spin.setRange(0.1, 250.0)
        self._fps_spin.setDecimals(1)
        self._fps_spin.setFixedWidth(80)
        self._fps_spin.valueChanged.connect(self._on_fps_changed)
        fps_unit_label = QLabel("fps")
        fps_unit_label.setStyleSheet(f"color: {COLOUR['text_dim']}; font-size: 12px;")
        self._fps_max_label = QLabel("")
        self._fps_max_label.setStyleSheet(f"color: {COLOUR['text_dim']}; font-size: 12px;")
        self._fps_info_btn = InfoButton(
            "The sensor mode sets the MAXIMUM framerate for that\n"
            "resolution and bit depth. Any lower framerate can be used.\n\n"
            "Low framerates are useful for:\n"
            "  · Timelapse-style image stacks (e.g. 1 fps or below)\n"
            "  · Long recordings where storage is the constraint\n"
            "  · Staying within the SD card's write budget at high resolution\n\n"
            "Lowering fps reduces the write rate proportionally, so it is the\n"
            "simplest way to gain write headroom without losing resolution."
        )
        fps_row.addWidget(self._fps_spin)
        fps_row.addWidget(fps_unit_label)
        fps_row.addWidget(self._fps_max_label)
        fps_row.addWidget(self._fps_info_btn)
        fps_row.addStretch()
        layout.addLayout(fps_row, row, 1)
        row += 1

        # Colour mode — greyscale uses only the Y plane (1 byte/px instead of 3)
        layout.addWidget(self._dim_label("Colour"), row, 0)
        colour_row = QHBoxLayout()
        colour_row.setSpacing(6)
        self._colour_combo = QComboBox()
        self._colour_combo.setFixedWidth(120)
        for colour_label, _channels in COLOUR_MODES:
            self._colour_combo.addItem(colour_label)
        default_index = self._colour_combo.findText(DEFAULT_COLOUR_MODE)
        if default_index >= 0:
            self._colour_combo.setCurrentIndex(default_index)
        self._colour_combo.currentIndexChanged.connect(self._on_colour_mode_changed)
        self._colour_info_btn = InfoButton(
            "Greyscale records only the luma (brightness) plane:\n"
            "1 byte per pixel instead of 3.\n\n"
            "  · ~3× smaller files for TIFF and PNG stacks\n"
            "  · ~2.5× smaller for MJPEG\n"
            "  · Correspondingly more write headroom\n\n"
            "Tracking algorithms work on brightness, not colour, so\n"
            "greyscale loses nothing relevant and is the recommended\n"
            "default. Choose Colour only if the analysis needs hue —\n"
            "for example distinguishing colour-marked individuals."
        )
        colour_row.addWidget(self._colour_combo)
        colour_row.addWidget(self._colour_info_btn)
        colour_row.addStretch()
        layout.addLayout(colour_row, row, 1)
        row += 1

        # Show preview toggle
        self._show_preview_check = QCheckBox("Show preview  (disable if Pi struggles)")
        self._show_preview_check.setChecked(True)
        self._show_preview_check.stateChanged.connect(self._on_preview_toggle)
        layout.addWidget(self._show_preview_check, row, 0, 1, 2)

        return group

    # ── Output settings group ──────────────────────────────────────────────────

    def _build_output_group(self) -> QGroupBox:
        group  = QGroupBox("Output")
        layout = QGridLayout(group)
        layout.setColumnStretch(1, 1)
        layout.setVerticalSpacing(6)

        row = 0

        # Save directory
        layout.addWidget(self._dim_label("Save to"), row, 0)
        dir_row = QHBoxLayout()
        dir_row.setSpacing(4)
        self._save_dir_edit = QLineEdit(self._profile["recording"]["save_dir"])
        self._save_dir_edit.setMinimumWidth(120)
        browse_button       = QPushButton()
        browse_button.setIcon(
            self.style().standardIcon(QStyle.StandardPixmap.SP_DirOpenIcon)
        )
        browse_button.setToolTip("Browse for save directory")
        browse_button.setFixedWidth(36)
        browse_button.clicked.connect(self._on_browse_save_dir)
        dir_row.addWidget(self._save_dir_edit)
        dir_row.addWidget(browse_button)
        layout.addLayout(dir_row, row, 1)
        row += 1

        # Format selector + ℹ popup for all-format comparison table
        layout.addWidget(self._dim_label("Format"), row, 0)
        format_row           = QHBoxLayout()
        format_row.setSpacing(4)
        self._format_combo   = QComboBox()
        self._format_combo.setMaxVisibleItems(len(OUTPUT_FORMATS))
        self._format_combo.setFixedWidth(160)
        for display_label, _, _ in OUTPUT_FORMATS:
            self._format_combo.addItem(display_label)
        self._format_combo.currentIndexChanged.connect(self._on_format_changed)
        self._format_info_btn = InfoButton()
        format_row.addWidget(self._format_combo)
        format_row.addWidget(self._format_info_btn)
        format_row.addStretch()
        layout.addLayout(format_row, row, 1)
        row += 1

        # Headroom indicator (updates live) + ℹ explaining what headroom means
        headroom_row = QHBoxLayout()
        headroom_row.setSpacing(4)
        self._headroom_label = QLabel("")
        self._headroom_label.setStyleSheet("font-size: 12px;")
        self._headroom_info_btn = InfoButton(
            "Write headroom is the fraction of your SD card's sustained write\n"
            "speed that is NOT used by the recording.\n\n"
            "Example: 30% headroom means the recording uses 70% of the card's\n"
            "write budget. At 0% the card can't keep up and frames are dropped.\n\n"
            "✔  > 30% — safe\n"
            "⚠  10–30% — marginal, frame drops possible under load\n"
            "✖  < 10% — expect frame drops\n\n"
            "Recalibrate under Settings if results seem off."
        )
        headroom_row.addWidget(self._headroom_label)
        headroom_row.addWidget(self._headroom_info_btn)
        headroom_row.addStretch()
        layout.addLayout(headroom_row, row, 0, 1, 2)
        row += 1

        # File name — auto-generated from metadata unless overridden
        auto_name_row = QHBoxLayout()
        auto_name_row.setSpacing(4)
        self._auto_name_check = QCheckBox("Name from metadata")
        self._auto_name_check.setChecked(True)
        self._auto_name_check.stateChanged.connect(self._on_auto_name_toggled)
        self._auto_name_info_btn = InfoButton(
            "When ticked, the file name is built automatically from the\n"
            "metadata fields:\n\n"
            "    {experiment}_{treatments}_{trial}\n\n"
            "Treatments are joined with '-'. Whether treatment NAMES are\n"
            "included alongside their values is set under\n"
            "Settings → File naming.\n\n"
            "    values only:  foraging_high-dim_3\n"
            "    with names:   foraging_density-high-light-dim_3\n\n"
            "Untick to type a name yourself. Parts that are empty or 'NA'\n"
            "are left out rather than appearing literally."
        )
        auto_name_row.addWidget(self._auto_name_check)
        auto_name_row.addWidget(self._auto_name_info_btn)
        auto_name_row.addStretch()
        layout.addLayout(auto_name_row, row, 1)
        row += 1

        layout.addWidget(self._dim_label("File name"), row, 0)
        self._file_name_edit = QLineEdit(self._profile["recording"]["base_name"])
        self._file_name_edit.setMinimumWidth(120)
        layout.addWidget(self._file_name_edit, row, 1)
        row += 1

        # Folder name (image stack mode only)
        self._folder_name_label = self._dim_label("Folder name")
        layout.addWidget(self._folder_name_label, row, 0)
        self._folder_name_edit = QLineEdit(self._profile["recording"]["folder_name"])
        self._folder_name_edit.setMinimumWidth(120)
        layout.addWidget(self._folder_name_edit, row, 1)
        row += 1

        # Duration — checkbox on its own row, spinbox below
        layout.addWidget(self._dim_label("Duration"), row, 0)
        self._duration_check = QCheckBox("Record until stopped")
        self._duration_check.setChecked(True)
        self._duration_check.stateChanged.connect(self._on_duration_toggle)
        layout.addWidget(self._duration_check, row, 1)
        row += 1

        duration_row = QHBoxLayout()
        duration_row.setSpacing(6)
        self._duration_spin = QSpinBox()
        self._duration_spin.setRange(1, 86400)
        self._duration_spin.setValue(60)
        self._duration_spin.setEnabled(False)
        self._duration_spin.setFixedWidth(100)
        duration_unit_label = QLabel("seconds")
        duration_unit_label.setStyleSheet(f"color: {COLOUR['text_dim']}; font-size: 12px;")
        duration_row.addWidget(self._duration_spin)
        duration_row.addWidget(duration_unit_label)
        duration_row.addStretch()
        layout.addLayout(duration_row, row, 1)
        row += 1

        return group

    # ── Metadata group ─────────────────────────────────────────────────────────

    def _build_metadata_group(self) -> QGroupBox:
        group  = QGroupBox("Metadata")
        layout = QGridLayout(group)
        layout.setColumnStretch(1, 1)
        layout.setVerticalSpacing(6)

        meta = self._profile["metadata"]
        row  = 0

        # ── Load metadata from a CSV list ──────────────────────────────────────
        load_row = QHBoxLayout()
        load_row.setSpacing(4)
        self._load_list_button = QPushButton("Load metadata from file…")
        self._load_list_button.setStyleSheet("font-size: 11px; padding: 3px 10px;")
        self._load_list_button.clicked.connect(self._on_load_metadata_list)
        self._list_info_btn = InfoButton(
            "Load a CSV of planned sessions and step through it between\n"
            "recordings, instead of typing metadata each time.\n\n"
            "COLUMN CONVENTION\n"
            "  Three column names are reserved:\n"
            "      experimenter, experiment, trial\n"
            "  EVERY OTHER COLUMN IS TREATED AS A TREATMENT — the column\n"
            "  name becomes the treatment name, the cell becomes its value.\n\n"
            "EXAMPLE\n"
            "      experiment,trial,density,light\n"
            "      foraging,1,high,dim\n"
            "      foraging,2,low,bright\n\n"
            "  gives two sessions, each with a density and a light treatment.\n\n"
            "Fields stay editable after loading, so you can adjust on the fly.\n"
            "The list advances automatically when a recording finishes.\n"
            "A ✓ marks rows whose output file already exists."
        )
        load_row.addWidget(self._load_list_button)
        load_row.addWidget(self._list_info_btn)
        load_row.addStretch()
        layout.addLayout(load_row, row, 0, 1, 2)
        row += 1

        # Navigation through the loaded list (hidden until a list is loaded)
        self._list_nav_widget = QWidget()
        nav_layout = QHBoxLayout(self._list_nav_widget)
        nav_layout.setContentsMargins(0, 0, 0, 0)
        nav_layout.setSpacing(4)

        self._list_prev_button = QPushButton("◀")
        self._list_prev_button.setFixedWidth(28)
        self._list_prev_button.setToolTip("Previous row  (Left arrow)")
        self._list_prev_button.clicked.connect(lambda: self._step_metadata_list(-1))

        self._list_combo = QComboBox()
        self._list_combo.setMinimumWidth(150)
        self._list_combo.currentIndexChanged.connect(self._on_list_row_selected)

        self._list_next_button = QPushButton("▶")
        self._list_next_button.setFixedWidth(28)
        self._list_next_button.setToolTip("Next row  (Right arrow)")
        self._list_next_button.clicked.connect(lambda: self._step_metadata_list(+1))

        self._list_clear_button = QPushButton("✕")
        self._list_clear_button.setFixedWidth(24)
        self._list_clear_button.setToolTip("Close the list and type metadata manually")
        self._list_clear_button.clicked.connect(self._on_clear_metadata_list)

        nav_layout.addWidget(self._list_prev_button)
        nav_layout.addWidget(self._list_combo, stretch=1)
        nav_layout.addWidget(self._list_next_button)
        nav_layout.addWidget(self._list_clear_button)
        self._list_nav_widget.setVisible(False)
        layout.addWidget(self._list_nav_widget, row, 0, 1, 2)
        row += 1

        # ── Fixed metadata fields ──────────────────────────────────────────────
        fixed_fields = [
            ("Experimenter", "experimenter"),
            ("Experiment",   "experiment"),
            ("Trial",        "trial"),
        ]
        self._meta_edits = {}
        for label_text, key in fixed_fields:
            layout.addWidget(self._dim_label(label_text), row, 0)
            edit = QLineEdit(str(meta.get(key, "NA")))
            edit.setPlaceholderText("NA")
            edit.setMinimumWidth(120)
            edit.textChanged.connect(self._refresh_auto_file_name)
            self._meta_edits[key] = edit
            layout.addWidget(edit, row, 1)
            row += 1

        # ── Treatments: any number of user-named name/value pairs ──────────────
        treatments_label = self._dim_label("Treatments")
        treatments_label.setAlignment(
            Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignTop
        )
        layout.addWidget(treatments_label, row, 0)
        self._treatment_list = TreatmentList()
        self._treatment_list.changed.connect(self._refresh_auto_file_name)
        layout.addWidget(self._treatment_list, row, 1)
        row += 1

        # ── Scale: choose which value you enter; the other is computed ────────
        layout.addWidget(self._dim_label("Scale"), row, 0)
        scale_mode_row = QHBoxLayout()
        scale_mode_row.setSpacing(10)
        self._scale_px_radio    = QRadioButton("px/cm")
        self._scale_width_radio = QRadioButton("frame width")
        self._scale_px_radio.setChecked(True)
        self._scale_button_group = QButtonGroup(self)
        self._scale_button_group.addButton(self._scale_px_radio,    0)
        self._scale_button_group.addButton(self._scale_width_radio, 1)
        self._scale_px_radio.toggled.connect(self._on_scale_mode_changed)
        scale_mode_row.addWidget(self._scale_px_radio)
        scale_mode_row.addWidget(self._scale_width_radio)
        scale_mode_row.addStretch()
        layout.addLayout(scale_mode_row, row, 1)
        row += 1

        # px/cm entry
        px_row = QHBoxLayout()
        px_row.setSpacing(6)
        self._px_per_cm_spin = QDoubleSpinBox()
        self._px_per_cm_spin.setRange(0.0, 99999.0)
        self._px_per_cm_spin.setDecimals(2)
        self._px_per_cm_spin.setSpecialValueText("—")
        self._px_per_cm_spin.setValue(0.0)
        self._px_per_cm_spin.setFixedWidth(100)
        self._px_per_cm_spin.valueChanged.connect(self._on_px_per_cm_changed)
        px_unit_label = QLabel("px/cm")
        px_unit_label.setStyleSheet(f"color: {COLOUR['text_dim']}; font-size: 12px;")
        px_row.addWidget(self._px_per_cm_spin)
        px_row.addWidget(px_unit_label)
        px_row.addStretch()
        layout.addLayout(px_row, row, 1)
        row += 1

        # frame width entry
        width_row = QHBoxLayout()
        width_row.setSpacing(6)
        self._frame_width_spin = QDoubleSpinBox()
        self._frame_width_spin.setRange(0.0, 999.0)
        self._frame_width_spin.setDecimals(2)
        self._frame_width_spin.setSpecialValueText("—")
        self._frame_width_spin.setValue(0.0)
        self._frame_width_spin.setFixedWidth(100)
        self._frame_width_spin.valueChanged.connect(self._on_frame_width_changed)
        width_unit_label = QLabel("cm frame width")
        width_unit_label.setStyleSheet(f"color: {COLOUR['text_dim']}; font-size: 12px;")
        width_row.addWidget(self._frame_width_spin)
        width_row.addWidget(width_unit_label)
        width_row.addStretch()
        layout.addLayout(width_row, row, 1)
        row += 1

        # Explanation of the computed relationship
        self._scale_hint_label = QLabel("")
        self._scale_hint_label.setStyleSheet(f"color: {COLOUR['text_dim']}; font-size: 11px;")
        self._scale_hint_label.setWordWrap(True)
        layout.addWidget(self._scale_hint_label, row, 0, 1, 2)

        return group

    # ── Profile group ──────────────────────────────────────────────────────────

    def _build_profile_group(self) -> QGroupBox:
        group  = QGroupBox("Profile")
        layout = QHBoxLayout(group)

        load_button = QPushButton("Load profile…")
        save_button = QPushButton("Save profile…")
        load_button.clicked.connect(self._on_load_profile)
        save_button.clicked.connect(self._on_save_profile)
        layout.addWidget(load_button)
        layout.addWidget(save_button)
        layout.addStretch()
        return group

    # ── Status panel (right side, during recording) ────────────────────────────

    def _build_status_panel(self) -> QWidget:
        panel  = QWidget()
        layout = QVBoxLayout(panel)
        layout.setSpacing(12)

        rec_label = QLabel("● RECORDING")
        rec_label.setStyleSheet(f"color: {COLOUR['red']}; font-size: 18px; font-weight: bold;")
        rec_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(rec_label)

        # Live stats — monospaced for alignment
        mono_font = QFont("DejaVu Sans Mono", 13)
        stats = [
            ("Elapsed",        "_elapsed_label"),
            ("Frames written", "_frames_label"),
            ("Dropped frames", "_dropped_label"),
            ("Write headroom", "_headroom_live_label"),
        ]
        grid = QGridLayout()
        for row, (stat_label, attr_name) in enumerate(stats):
            dim = self._dim_label(stat_label)
            val = QLabel("—")
            val.setFont(mono_font)
            val.setStyleSheet(f"color: {COLOUR['accent']};")
            setattr(self, attr_name, val)
            grid.addWidget(dim, row, 0)
            grid.addWidget(val, row, 1)

        layout.addLayout(grid)

        # Warnings area
        self._warning_label = QLabel("")
        self._warning_label.setWordWrap(True)
        self._warning_label.setStyleSheet(f"color: {COLOUR['red']}; font-size: 12px;")
        layout.addWidget(self._warning_label)

        stop_hint = QLabel("Press  q  or click Stop to end the recording")
        stop_hint.setStyleSheet(f"color: {COLOUR['text_dim']}; font-size: 11px;")
        stop_hint.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(stop_hint)

        layout.addStretch()
        return panel

    # ── Bottom bar ─────────────────────────────────────────────────────────────

    def _build_bottom_bar(self) -> QWidget:
        bar    = QWidget()
        bar.setFixedHeight(52)
        bar.setStyleSheet(f"background-color: {COLOUR['panel']}; border-top: 1px solid {COLOUR['border']};")
        layout = QHBoxLayout(bar)
        layout.setContentsMargins(12, 6, 12, 6)

        self._record_button = QPushButton("▶  Start recording")
        self._record_button.setFixedHeight(38)
        self._record_button.setMinimumWidth(200)
        self._record_button.setStyleSheet(
            f"background-color: {COLOUR['button_start']}; color: white; "
            f"font-size: 14px; font-weight: bold; border-radius: 4px; border: none;"
        )
        self._record_button.clicked.connect(self._on_record_toggle)

        self._bottom_status = QLabel("Ready")
        self._bottom_status.setStyleSheet(f"color: {COLOUR['text_dim']}; font-size: 12px;")

        layout.addWidget(self._record_button)
        layout.addSpacing(16)
        layout.addWidget(self._bottom_status)
        layout.addStretch()
        return bar

    # =========================================================================
    # Camera and preview
    # =========================================================================

    def _populate_sensor_modes(self) -> None:
        self._sensor_mode_combo.blockSignals(True)
        for mode in self._camera.sensor_modes:
            self._sensor_mode_combo.addItem(mode.display_label)
        self._sensor_mode_combo.blockSignals(False)
        self._on_sensor_mode_changed(0)

    def _start_preview(self) -> None:
        if self._show_preview_check.isChecked():
            self._camera.start_preview(
                callback = lambda frame: self.frame_ready.emit(frame),
                fps      = 10,
            )

    def _current_sensor_mode(self) -> SensorMode:
        index = self._sensor_mode_combo.currentIndex()
        return self._camera.sensor_modes[index]

    # =========================================================================
    # Headroom and tooltip refresh
    # =========================================================================

    def _refresh_free_space(self) -> None:
        save_dir = Path(self._save_dir_edit.text())
        if save_dir.exists():
            self._free_space_gb = get_free_space_gb(save_dir)

    def _refresh_headroom(self) -> None:
        """
        Update the inline headroom indicator for the selected format and
        push the all-formats comparison table to the format ℹ button.
        Uses the user-selected framerate, not the sensor mode maximum.
        """
        write_speed   = self._app_config["hardware"].get("sd_write_speed_mbs")
        mode          = self._current_sensor_mode()
        selected_fps  = self._fps_spin.value()
        channels      = self._current_channels()
        format_idx    = self._format_combo.currentIndex()
        format_label, _, _ = OUTPUT_FORMATS[format_idx]

        # Update the ℹ popup with the full comparison table
        table_text = _build_all_formats_tooltip(
            mode, selected_fps, channels, write_speed, self._free_space_gb,
        )
        self._format_info_btn.set_text(table_text)

        # Inline headroom for the currently selected format only
        if write_speed:
            headroom = compute_headroom(
                format_label, mode.width, mode.height, selected_fps,
                write_speed, channels,
            )
            colour = {
                "green": COLOUR["green"],
                "amber": COLOUR["amber"],
                "red":   COLOUR["red"],
            }[headroom["colour"]]
            icon = {"green": "✔", "amber": "⚠", "red": "✖"}[headroom["colour"]]
            self._headroom_label.setText(
                f"Write headroom: {headroom['headroom_pct']:.0f}%  {icon}"
            )
            self._headroom_label.setStyleSheet(f"color: {colour}; font-size: 12px;")
        else:
            self._headroom_label.setText("Write speed not calibrated")
            self._headroom_label.setStyleSheet(f"color: {COLOUR['text_dim']}; font-size: 12px;")

    # =========================================================================
    # Slots
    # =========================================================================

    def _on_sensor_mode_changed(self, index: int) -> None:
        if index < 0 or index >= len(self._camera.sensor_modes):
            return
        mode = self._camera.sensor_modes[index]

        # Clamp the fps field to the new mode's ceiling BEFORE switching modes,
        # so set_mode() (which restarts the preview) picks up the correct
        # target fps rather than a stale one from the previous mode.
        self._fps_spin.blockSignals(True)
        self._fps_spin.setMaximum(mode.max_fps)
        if self._fps_spin.value() > mode.max_fps:
            self._fps_spin.setValue(mode.max_fps)
        elif self._fps_spin.value() <= 0.1:
            self._fps_spin.setValue(mode.max_fps)
        self._fps_spin.blockSignals(False)
        self._fps_max_label.setText(f"max {mode.max_fps:.1f}")

        self._camera.set_capture_fps(self._fps_spin.value())
        self._camera.set_mode(mode)   # restarts preview; applies target fps on start

        # Frame geometry changed — a zoom region from the old mode is no
        # longer meaningful, so return to the full view
        if hasattr(self, "_preview_widget"):
            self._preview_widget.reset_view()

        # Field of view and/or pixel count changed — recompute the scale from
        # the stored full-sensor calibration so it stays physically correct
        if hasattr(self, "_scale_px_radio"):
            self._rescale_for_new_sensor_mode()

        self._refresh_headroom()

    def _on_fps_changed(self, value: float) -> None:
        self._camera.set_capture_fps(value)
        self._refresh_headroom()

    # ── Scale: px/cm and frame width are two views of the same number ─────────

    def _on_scale_mode_changed(self, _checked: bool = False) -> None:
        """
        Enable whichever scale field the user chose to enter, disable the other.
        The disabled one is not empty — it shows the value derived from the
        entered one, so both are always visible and consistent.
        """
        px_is_authoritative = self._scale_px_radio.isChecked()
        self._px_per_cm_spin.setEnabled(px_is_authoritative)
        self._frame_width_spin.setEnabled(not px_is_authoritative)
        self._recompute_derived_scale()

    def _on_px_per_cm_changed(self, _value: float) -> None:
        if self._scale_px_radio.isChecked():
            self._recompute_derived_scale()

    def _on_frame_width_changed(self, _value: float) -> None:
        if self._scale_width_radio.isChecked():
            self._recompute_derived_scale()

    def _recompute_derived_scale(self) -> None:
        """
        Derive the non-authoritative scale value from the authoritative one.

        The calibration is anchored to the PHYSICAL scene, not the pixel
        count, because these vary independently across sensor modes:

          · 4056×3040 and 2028×1520 see the same scene (both full sensor).
            Switching between them halves px_per_cm but leaves the frame's
            physical width unchanged.
          · 1332×990 reads only the central 66% of the sensor, so it sees a
            physically narrower scene at the same optical setup.

        We therefore store the calibration internally as the scene width the
        FULL sensor would see (`_full_fov_width_cm`), and derive both
        displayed values from it for whichever mode is active.
        """
        mode           = self._current_sensor_mode()
        frame_width_px = mode.width
        fov_fraction   = mode.fov_fraction_width

        if self._scale_px_radio.isChecked():
            px_per_cm = self._px_per_cm_spin.value()
            if px_per_cm > 0:
                frame_width_cm          = frame_width_px / px_per_cm
                self._full_fov_width_cm = frame_width_cm / fov_fraction
            else:
                frame_width_cm          = 0.0
                self._full_fov_width_cm = None
            self._frame_width_spin.blockSignals(True)
            self._frame_width_spin.setValue(frame_width_cm)
            self._frame_width_spin.blockSignals(False)
        else:
            frame_width_cm = self._frame_width_spin.value()
            if frame_width_cm > 0:
                px_per_cm               = frame_width_px / frame_width_cm
                self._full_fov_width_cm = frame_width_cm / fov_fraction
            else:
                px_per_cm               = 0.0
                self._full_fov_width_cm = None
            self._px_per_cm_spin.blockSignals(True)
            self._px_per_cm_spin.setValue(px_per_cm)
            self._px_per_cm_spin.blockSignals(False)

        self._update_scale_hint(mode)

    def _rescale_for_new_sensor_mode(self) -> None:
        """
        Called when the sensor mode changes. Recomputes both scale values
        from the stored full-sensor calibration, so an existing calibration
        stays physically correct across mode changes rather than being
        silently reinterpreted.
        """
        mode = self._current_sensor_mode()

        if self._full_fov_width_cm is None:
            self._update_scale_hint(mode)
            return

        frame_width_cm = self._full_fov_width_cm * mode.fov_fraction_width
        px_per_cm      = mode.width / frame_width_cm if frame_width_cm > 0 else 0.0

        self._frame_width_spin.blockSignals(True)
        self._px_per_cm_spin.blockSignals(True)
        self._frame_width_spin.setValue(frame_width_cm)
        self._px_per_cm_spin.setValue(px_per_cm)
        self._frame_width_spin.blockSignals(False)
        self._px_per_cm_spin.blockSignals(False)

        self._update_scale_hint(mode)

    def _update_scale_hint(self, mode) -> None:
        """Explain what the current numbers mean for the active sensor mode."""
        if self._px_per_cm_spin.value() <= 0:
            self._scale_hint_label.setText(
                "Enter a value to set the spatial scale (optional)."
            )
            return

        if mode.is_full_fov:
            fov_note = "full sensor field of view"
        else:
            fov_note = (
                f"cropped field of view — this mode sees "
                f"{mode.fov_fraction_width * 100:.0f}% of the scene width"
            )
        self._scale_hint_label.setText(
            f"{mode.width} px across {self._frame_width_spin.value():.2f} cm "
            f"({fov_note}). Recalculated automatically when the sensor mode changes."
        )

    def _on_colour_mode_changed(self, _index: int) -> None:
        self._camera.set_colour_mode(self._current_channels())
        self._refresh_headroom()

    def _current_channels(self) -> int:
        """Return 1 for greyscale, 3 for colour."""
        label = self._colour_combo.currentText()
        for colour_label, channels in COLOUR_MODES:
            if colour_label == label:
                return channels
        return 3

    def _on_format_changed(self, _index: int) -> None:
        self._refresh_headroom()
        # Folder name applies to image stacks only; file name to both
        format_label   = self._format_combo.currentText()
        is_image_stack = "stack" in format_label.lower()
        self._folder_name_edit.setEnabled(is_image_stack)
        self._folder_name_label.setEnabled(is_image_stack)
        if is_image_stack:
            self._folder_name_edit.setToolTip(
                "Images are written into this folder, named "
                "{file name}_00001.tiff, _00002.tiff, and so on."
            )
        else:
            self._folder_name_edit.setToolTip(
                "Only used for image stacks — video formats write a single file."
            )

    def _on_preview_toggle(self, state: int) -> None:
        if state == Qt.CheckState.Checked.value:
            self._start_preview()
            self._preview_widget.setText("")
        else:
            self._camera.stop_preview()
            self._preview_widget.setText("Preview disabled")

    def _on_browse_save_dir(self) -> None:
        chosen_dir = QFileDialog.getExistingDirectory(
            self, "Select save directory", self._save_dir_edit.text()
        )
        if chosen_dir:
            self._save_dir_edit.setText(chosen_dir)
            self._refresh_free_space()
            self._refresh_headroom()

    def _on_duration_toggle(self, state: int) -> None:
        self._duration_spin.setEnabled(state != Qt.CheckState.Checked.value)

    def _on_record_toggle(self) -> None:
        if self._is_recording:
            self._stop_recording()
        else:
            self._start_recording()

    def _collect_recording_settings(self) -> RecordingSettings:
        """Assemble a RecordingSettings object from the current form state."""
        mode = self._current_sensor_mode()

        px_per_cm      = self._px_per_cm_spin.value()
        frame_width_cm = self._frame_width_spin.value()
        # Zero means "not set" — both fields are kept in sync, so if one is
        # unset the other is too.
        px_per_cm      = None if px_per_cm      <= 0 else round(px_per_cm, 2)
        frame_width_cm = None if frame_width_cm <= 0 else round(frame_width_cm, 2)

        metadata_values = {key: edit.text() for key, edit in self._meta_edits.items()}
        metadata_values["treatments"]     = self._treatment_list.get_treatments()
        metadata_values["px_per_cm"]      = px_per_cm
        metadata_values["frame_width_cm"] = frame_width_cm
        metadata_values["scale_entered_as"] = (
            "px_per_cm" if self._scale_px_radio.isChecked() else "frame_width_cm"
        )

        return RecordingSettings(
            save_dir     = Path(self._save_dir_edit.text()),
            file_name    = self._file_name_edit.text().strip() or "recording",
            folder_name  = self._folder_name_edit.text().strip() or "images",
            format_label = self._format_combo.currentText(),
            frame_width  = mode.width,
            frame_height = mode.height,
            fps          = self._fps_spin.value(),
            channels     = self._current_channels(),
            duration_s   = None if self._duration_check.isChecked()
                           else float(self._duration_spin.value()),
            fov_fraction = mode.fov_fraction_width,
            metadata     = metadata_values,
        )

    def _start_recording(self) -> None:
        from PyQt6.QtWidgets import QMessageBox

        settings = self._collect_recording_settings()

        # ── Validation ─────────────────────────────────────────────────────────
        if not settings.save_dir.exists():
            QMessageBox.warning(
                self, "Save directory not found",
                f"The save directory does not exist:\n{settings.save_dir}"
            )
            return

        target = settings.output_dir if settings.is_image_stack else settings.video_file
        if target.exists():
            overwrite = QMessageBox.question(
                self, "Overwrite existing output?",
                f"This already exists:\n{target}\n\nOverwrite it?",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.No,
            )
            if overwrite != QMessageBox.StandardButton.Yes:
                return

        # ── Start ──────────────────────────────────────────────────────────────
        try:
            self._session = RecordingSession(self._camera, settings)
            self._session.start()
        except Exception as start_error:
            QMessageBox.critical(
                self, "Could not start recording", str(start_error)
            )
            self._session = None
            return

        self._recording_settings = settings
        self._is_recording       = True

        self._setup_panel.setVisible(False)
        self._status_panel.setVisible(True)
        self._record_button.setText("■  Stop recording")
        self._record_button.setStyleSheet(
            f"background-color: {COLOUR['button_stop']}; color: white; "
            f"font-size: 14px; font-weight: bold; border-radius: 4px; border: none;"
        )
        self._bottom_status.setText(f"Recording to {target.name}")
        self._warning_label.setText("")

        # Poll the session for live stats
        self._status_timer.start(250)

    def _stop_recording(self) -> None:
        from PyQt6.QtWidgets import QMessageBox

        self._status_timer.stop()

        capture_summary = {}
        if self._session is not None:
            capture_summary = self._session.stop()

        # ── Write the metadata sidecar ─────────────────────────────────────────
        if self._recording_settings is not None:
            try:
                metadata_dict = build_metadata(self._recording_settings, capture_summary)
                write_metadata(metadata_dict, self._recording_settings.metadata_file)
            except Exception as metadata_error:
                QMessageBox.warning(
                    self, "Metadata not saved",
                    f"The recording completed but the metadata file could not "
                    f"be written:\n{metadata_error}"
                )

        self._is_recording = False
        self._session      = None

        self._setup_panel.setVisible(True)
        self._status_panel.setVisible(False)
        self._record_button.setText("▶  Start recording")
        self._record_button.setStyleSheet(
            f"background-color: {COLOUR['button_start']}; color: white; "
            f"font-size: 14px; font-weight: bold; border-radius: 4px; border: none;"
        )

        # ── Summarise the result in the status bar ─────────────────────────────
        frames_written = capture_summary.get("frames_written", 0)
        frames_dropped = capture_summary.get("frames_dropped", 0)
        duration_s     = capture_summary.get("actual_duration_s", 0.0)
        effective_fps  = capture_summary.get("effective_fps", 0.0)

        self._bottom_status.setText(
            f"Saved {frames_written} frames in {duration_s:.1f} s "
            f"({effective_fps:.1f} fps effective, {frames_dropped} dropped)"
        )

        if capture_summary.get("error"):
            QMessageBox.critical(
                self, "Recording error",
                f"The recording stopped because of an error:\n\n"
                f"{capture_summary['error']}"
            )

        # Update the ✓ marks now that a new file exists, then advance to the
        # next planned session so the experimenter can start the next trial
        # without touching the metadata fields.
        self._refresh_list_recorded_marks()
        if self._metadata_rows and not capture_summary.get("error"):
            current_index = self._list_combo.currentIndex()
            if current_index < len(self._metadata_rows) - 1:
                self._list_combo.setCurrentIndex(current_index + 1)
            else:
                self._bottom_status.setText(
                    self._bottom_status.text() + "   —   end of metadata list"
                )

    # ── Live status updates during recording ───────────────────────────────────

    def _update_recording_status(self) -> None:
        """Called by a QTimer while recording; refreshes the status panel."""
        if self._session is None:
            return

        stats = self._session.stats

        self._elapsed_label.setText(f"{stats.elapsed_s:7.1f} s")
        self._frames_label.setText(f"{stats.frames_written:7d}")
        self._dropped_label.setText(
            f"{stats.frames_dropped:7d}  ({stats.drop_rate_pct:.1f}%)"
        )

        # Queue depth is the live indicator of whether the disk is keeping up
        queue_pct = min(100, int(100 * stats.queue_depth / 60))
        self._headroom_live_label.setText(f"queue {queue_pct:3d}% full")
        if queue_pct > 80:
            queue_colour = COLOUR["red"]
        elif queue_pct > 50:
            queue_colour = COLOUR["amber"]
        else:
            queue_colour = COLOUR["green"]
        self._headroom_live_label.setStyleSheet(f"color: {queue_colour};")

        # ── Warnings with concrete suggestions ─────────────────────────────────
        self._update_drop_warning(stats)

        # Auto-stop once the capture thread has finished a fixed-duration run
        if not self._session.is_running:
            self._stop_recording()

    def _update_drop_warning(self, stats) -> None:
        """Show an actionable warning if frames are being dropped."""
        if stats.frames_dropped == 0:
            self._warning_label.setText("")
            return

        drop_rate = stats.drop_rate_pct
        if drop_rate < 1.0:
            self._warning_label.setStyleSheet(f"color: {COLOUR['amber']}; font-size: 12px;")
            self._warning_label.setText(
                f"⚠ {stats.frames_dropped} frames dropped ({drop_rate:.1f}%). "
                f"Occasional drops at this rate are usually tolerable for tracking."
            )
            return

        # Build a suggestion ordered by how much it helps and how little it costs
        suggestions = []
        if self._current_channels() == 3:
            suggestions.append("switch to Greyscale (~3× less data)")
        if self._fps_spin.value() > 5:
            suggestions.append("lower the framerate")
        if self._format_combo.currentText() != "H.264 video (.mp4)":
            suggestions.append("use H.264 (much smaller, though less ideal for tracking)")
        if self._show_preview_check.isChecked():
            suggestions.append("disable the preview")
        suggestions.append("choose a lower resolution")

        self._warning_label.setStyleSheet(f"color: {COLOUR['red']}; font-size: 12px;")
        self._warning_label.setText(
            f"✖ {stats.frames_dropped} frames dropped ({drop_rate:.1f}%) — "
            f"the SD card cannot keep up.\n\n"
            f"Stop and try: {'; '.join(suggestions[:3])}."
        )

    def _on_load_profile(self) -> None:
        from PyQt6.QtWidgets import QMessageBox

        profile_file, _ = QFileDialog.getOpenFileName(
            self, "Load profile", self._save_dir_edit.text(), "YAML files (*.yaml *.yml)"
        )
        if not profile_file:
            return

        try:
            loaded_profile = load_profile(Path(profile_file))
        except Exception as load_error:
            QMessageBox.critical(
                self, "Could not read profile",
                f"The file could not be read as YAML:\n\n{load_error}"
            )
            return

        if not isinstance(loaded_profile, dict):
            QMessageBox.warning(
                self, "Not a profile file",
                "This YAML file does not contain a profile."
            )
            return

        # A profile must have at least one of the three expected sections.
        # Without this check, loading the wrong YAML (a metadata sidecar, or
        # config_app.yaml) silently does nothing, which looks like a bug.
        expected_sections = {"recording", "camera", "metadata"}
        if not expected_sections.intersection(loaded_profile.keys()):
            QMessageBox.warning(
                self, "Not a profile file",
                f"This YAML file has no profile sections.\n\n"
                f"Expected at least one of: {', '.join(sorted(expected_sections))}\n"
                f"Found: {', '.join(sorted(loaded_profile.keys())) or '(empty file)'}\n\n"
                f"Recording metadata files and config_app.yaml are not profiles."
            )
            return

        self._profile = loaded_profile
        self._apply_profile_to_ui()
        self._bottom_status.setText(f"Loaded profile: {Path(profile_file).name}")

    def _on_save_profile(self) -> None:
        from PyQt6.QtWidgets import QMessageBox

        profile_file, _ = QFileDialog.getSaveFileName(
            self, "Save profile", self._save_dir_edit.text(), "YAML files (*.yaml *.yml)"
        )
        if not profile_file:
            return

        # Ensure the file has a .yaml suffix, otherwise it won't appear in the
        # load dialog's filter later
        profile_path = Path(profile_file)
        if profile_path.suffix.lower() not in (".yaml", ".yml"):
            profile_path = profile_path.with_suffix(".yaml")

        try:
            save_profile(self._collect_profile_from_ui(), profile_path)
            self._bottom_status.setText(f"Saved profile: {profile_path.name}")
        except Exception as save_error:
            QMessageBox.critical(
                self, "Could not save profile", str(save_error)
            )

    def _on_recalibrate_write_speed(self) -> None:
        from benchmark import measure_write_speed_mbs
        from PyQt6.QtWidgets import QMessageBox
        save_dir = Path(self._save_dir_edit.text())
        if not save_dir.exists():
            QMessageBox.warning(self, "Error", f"Save directory does not exist:\n{save_dir}")
            return
        self._bottom_status.setText("Measuring write speed… (this takes ~10 s)")
        QApplication.processEvents()
        write_speed_mbs = measure_write_speed_mbs(save_dir)
        self._app_config["hardware"]["sd_write_speed_mbs"] = write_speed_mbs
        from datetime import date
        self._app_config["hardware"]["sd_write_speed_measured_date"] = str(date.today())
        save_app_config(self._app_config)
        self._refresh_headroom()
        self._bottom_status.setText(f"Write speed: {write_speed_mbs:.1f} MB/s  (calibrated today)")

    # =========================================================================
    # Profile helpers
    # =========================================================================

    def _collect_profile_from_ui(self) -> dict:
        return {
            "recording": {
                "save_dir":      self._save_dir_edit.text(),
                "output_format": self._format_combo.currentText(),
                "duration_s":    None if self._duration_check.isChecked() else self._duration_spin.value(),
                "base_name":      self._file_name_edit.text(),
                "auto_file_name": self._auto_name_check.isChecked(),
                "folder_name":   self._folder_name_edit.text(),
            },
            "camera": {
                "sensor_mode": self._sensor_mode_combo.currentIndex(),
                "fps":         self._fps_spin.value(),
                "colour_mode": self._colour_combo.currentText(),
            },
            "metadata": {
                key: edit.text() for key, edit in self._meta_edits.items()
            } | {
                "treatments":       self._treatment_list.get_treatments(),
                "px_per_cm":        self._px_per_cm_spin.value() or None,
                "frame_width_cm":   self._frame_width_spin.value() or None,
                "scale_entered_as": ("px_per_cm" if self._scale_px_radio.isChecked()
                                     else "frame_width_cm"),
            },
        }

    def _apply_profile_to_ui(self) -> None:
        rec  = self._profile.get("recording", {})
        meta = self._profile.get("metadata",  {})
        cam  = self._profile.get("camera",    {})

        if "save_dir"      in rec: self._save_dir_edit.setText(rec["save_dir"])
        if "output_format" in rec:
            index = self._format_combo.findText(rec["output_format"])
            if index >= 0:
                self._format_combo.setCurrentIndex(index)
        if "auto_file_name" in rec:
            self._auto_name_check.setChecked(bool(rec["auto_file_name"]))
        if "base_name" in rec and not self._auto_name_check.isChecked():
            self._file_name_edit.setText(rec["base_name"])
        if "folder_name"   in rec: self._folder_name_edit.setText(rec["folder_name"])
        if "duration_s"    in rec:
            if rec["duration_s"] is None:
                self._duration_check.setChecked(True)
            else:
                self._duration_check.setChecked(False)
                self._duration_spin.setValue(int(rec["duration_s"]))

        for key, edit in self._meta_edits.items():
            if key in meta:
                edit.setText(str(meta[key]))

        if "treatments" in meta and isinstance(meta["treatments"], dict):
            self._treatment_list.set_treatments(meta["treatments"])

        # Restore the scale: set the mode first, then the authoritative value,
        # which recomputes the derived one automatically.
        scale_mode = meta.get("scale_entered_as", "px_per_cm")
        if scale_mode == "frame_width_cm":
            self._scale_width_radio.setChecked(True)
            if meta.get("frame_width_cm"):
                self._frame_width_spin.setValue(float(meta["frame_width_cm"]))
        else:
            self._scale_px_radio.setChecked(True)
            if meta.get("px_per_cm"):
                self._px_per_cm_spin.setValue(float(meta["px_per_cm"]))

        if "sensor_mode" in cam and cam["sensor_mode"] is not None:
            self._sensor_mode_combo.setCurrentIndex(cam["sensor_mode"])
        # fps must be applied after sensor_mode, since the mode sets the ceiling
        if "fps" in cam and cam["fps"] is not None:
            self._fps_spin.setValue(float(cam["fps"]))
        if "colour_mode" in cam and cam["colour_mode"]:
            colour_index = self._colour_combo.findText(cam["colour_mode"])
            if colour_index >= 0:
                self._colour_combo.setCurrentIndex(colour_index)

    # =========================================================================
    # Helpers
    # =========================================================================

    def _dim_label(self, text: str) -> QLabel:
        label = QLabel(text)
        label.setStyleSheet(f"color: {COLOUR['text_dim']}; font-size: 12px;")
        label.setMinimumWidth(100)
        label.setMaximumWidth(100)
        return label

    # =========================================================================
    # Automatic file naming from metadata
    # =========================================================================

    def _on_treatment_names_toggled(self, checked: bool) -> None:
        """Switch between 'high-dim' and 'density-high-light-dim' naming."""
        self._app_config["app"]["include_treatment_names"] = checked
        save_app_config(self._app_config)
        self._refresh_auto_file_name()

    def _on_auto_name_toggled(self, _state: int) -> None:
        is_auto = self._auto_name_check.isChecked()
        self._file_name_edit.setReadOnly(is_auto)
        self._file_name_edit.setEnabled(not is_auto)
        if is_auto:
            self._refresh_auto_file_name()

    def _refresh_auto_file_name(self) -> None:
        """Rebuild the file name from metadata, if auto-naming is active."""
        if not hasattr(self, "_auto_name_check"):
            return
        if not self._auto_name_check.isChecked():
            return

        include_names = self._app_config["app"].get("include_treatment_names", False)
        auto_name = build_auto_file_name(
            experiment              = self._meta_edits["experiment"].text(),
            treatments              = self._treatment_list.get_treatments(),
            trial                   = self._meta_edits["trial"].text(),
            include_treatment_names = include_names,
        )
        self._file_name_edit.setText(auto_name)

        # A changed name changes which outputs already exist
        self._refresh_list_recorded_marks()

    # =========================================================================
    # Metadata list (CSV) loading and navigation
    # =========================================================================

    def _on_load_metadata_list(self) -> None:
        from PyQt6.QtWidgets import QMessageBox

        csv_file, _ = QFileDialog.getOpenFileName(
            self, "Load metadata list", self._save_dir_edit.text(),
            "CSV files (*.csv);;All files (*)"
        )
        if not csv_file:
            return

        try:
            rows, warnings = load_metadata_list(Path(csv_file))
        except Exception as load_error:
            QMessageBox.critical(
                self, "Could not read metadata list",
                f"{load_error}\n\n"
                f"The file needs a header row. Reserved column names are "
                f"experimenter, experiment and trial; every other column is "
                f"treated as a treatment."
            )
            return

        self._metadata_rows      = rows
        self._metadata_list_file = Path(csv_file)

        self._list_combo.blockSignals(True)
        self._list_combo.clear()
        for row in rows:
            self._list_combo.addItem(row.summary())
        self._list_combo.blockSignals(False)

        self._list_nav_widget.setVisible(True)
        self._list_combo.setCurrentIndex(0)
        self._apply_metadata_row(0)
        self._refresh_list_recorded_marks()

        message = f"Loaded {len(rows)} rows from {Path(csv_file).name}"
        if warnings:
            message += "  —  " + "; ".join(warnings)
        self._bottom_status.setText(message)

    def _on_clear_metadata_list(self) -> None:
        """Close the list; metadata fields stay as they are and become manual."""
        self._metadata_rows      = []
        self._metadata_list_file = None
        self._list_combo.blockSignals(True)
        self._list_combo.clear()
        self._list_combo.blockSignals(False)
        self._list_nav_widget.setVisible(False)
        self._bottom_status.setText("Metadata list closed — fields are manual again")

    def _on_list_row_selected(self, index: int) -> None:
        if 0 <= index < len(self._metadata_rows):
            self._apply_metadata_row(index)

    def _step_metadata_list(self, step: int) -> None:
        """Move by step rows, clamped to the ends of the list."""
        if not self._metadata_rows:
            return
        new_index = self._list_combo.currentIndex() + step
        new_index = max(0, min(new_index, len(self._metadata_rows) - 1))
        self._list_combo.setCurrentIndex(new_index)

    def _apply_metadata_row(self, index: int) -> None:
        """Populate the metadata fields from one row of the loaded list."""
        if not (0 <= index < len(self._metadata_rows)):
            return
        row = self._metadata_rows[index]

        self._meta_edits["experimenter"].setText(row.experimenter)
        self._meta_edits["experiment"].setText(row.experiment)
        self._meta_edits["trial"].setText(row.trial)
        self._treatment_list.set_treatments(row.treatments)

        self._refresh_auto_file_name()

    def _refresh_list_recorded_marks(self) -> None:
        """
        Mark rows in the dropdown whose output file already exists, so it is
        obvious at a glance which sessions still need recording.

        This only works while auto-naming is on, because otherwise there is
        no way to know which file a given row would produce.
        """
        if not self._metadata_rows or not hasattr(self, "_list_combo"):
            return
        if not self._auto_name_check.isChecked():
            return

        save_dir      = Path(self._save_dir_edit.text())
        include_names = self._app_config["app"].get("include_treatment_names", False)
        format_label  = self._format_combo.currentText()
        is_stack      = "stack" in format_label.lower()
        extension     = next(
            (ext for label, ext, _ in OUTPUT_FORMATS if label == format_label), ".avi"
        )

        current_index = self._list_combo.currentIndex()
        self._list_combo.blockSignals(True)
        for index, row in enumerate(self._metadata_rows):
            file_name = build_auto_file_name(
                row.experiment, row.treatments, row.trial, include_names
            )
            target = (save_dir / file_name) if is_stack \
                else (save_dir / f"{file_name}{extension}")
            mark = "✓  " if target.exists() else "     "
            self._list_combo.setItemText(index, f"{mark}{row.summary()}")
        self._list_combo.setCurrentIndex(current_index)
        self._list_combo.blockSignals(False)

    def keyPressEvent(self, event) -> None:
        """
        `q` stops an in-progress recording.
        Left/Right arrows step through the metadata list — but only when the
        focus isn't in a text field, so arrow keys still move the cursor
        normally while editing.
        """
        key = event.key()

        if key == Qt.Key.Key_Q and self._is_recording:
            self._stop_recording()
            return

        if key in (Qt.Key.Key_Left, Qt.Key.Key_Right) and self._metadata_rows:
            focus_widget = QApplication.focusWidget()
            is_editing   = isinstance(focus_widget, (QLineEdit, QSpinBox, QDoubleSpinBox))
            if not is_editing:
                self._step_metadata_list(-1 if key == Qt.Key.Key_Left else +1)
                return

        super().keyPressEvent(event)

    # =========================================================================
    # Cleanup
    # =========================================================================

    def closeEvent(self, event) -> None:
        # Finish any in-progress recording so the file and metadata are valid
        if self._is_recording:
            self._stop_recording()
        self._camera.release()
        super().closeEvent(event)
